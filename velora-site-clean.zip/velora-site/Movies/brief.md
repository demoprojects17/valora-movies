# Velora Movies

## What it is
Velora is a personal movies, anime and series tracker. Refresh the existing interface using the linked codebase as the source for features and Georgian copy. This workspace contains independent design artboards, not changes to the production app.

## Audience
Georgian and English speaking viewers who collect titles, track episodes, rate what they watch and synchronize their library across devices.

## Pages
Existing views: home, movies, anime, series, watchlist and viewing history. Supporting flows: add/search title, ratings and status, episode tracking, authentication and profile, backup and Letterboxd import.

## Constraints
Preserve the personal-library purpose and existing functional scope. Use Georgian copy for initial artboards. Support 1200, 768 and 390 widths. All writes stay inside this workspace; linked codebase is read-only. The user authorized an alternative workflow without the unavailable studio and knowledge MCP tools.
