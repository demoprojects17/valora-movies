import { VeloraScreen } from "./design-system";

export default function VeloraHomeNight() {
  return <VeloraScreen initialPage="home" initialTheme="night" />;
}
