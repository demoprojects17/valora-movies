import { VeloraScreen } from "./design-system";

export default function VeloraMovies() {
  return <VeloraScreen initialPage="movies" />;
}
