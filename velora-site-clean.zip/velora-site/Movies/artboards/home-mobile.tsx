import { VeloraScreen } from "./design-system";

export default function VeloraHomeMobile() {
  return <VeloraScreen initialPage="home" />;
}
