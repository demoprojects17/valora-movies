import { VeloraScreen } from "./design-system";

export default function VeloraAddTitle() {
  return <VeloraScreen initialPage="movies" initialAdd />;
}
