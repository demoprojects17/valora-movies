import { VeloraScreen } from "./design-system";

export default function VeloraWatchlist() {
  return <VeloraScreen initialPage="watchlist" />;
}
