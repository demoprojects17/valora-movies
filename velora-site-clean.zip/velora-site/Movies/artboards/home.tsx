import { VeloraScreen } from "./design-system";

export default function VeloraHome() {
  return <VeloraScreen initialPage="home" />;
}
