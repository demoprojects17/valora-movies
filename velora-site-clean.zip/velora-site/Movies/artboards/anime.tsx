import { VeloraScreen } from "./design-system";

export default function VeloraAnime() {
  return <VeloraScreen initialPage="anime" />;
}
