import { VeloraScreen } from "./design-system";

export default function VeloraHomeBright() {
  return <VeloraScreen initialPage="home" initialTheme="bright" />;
}
