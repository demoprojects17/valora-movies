import { VeloraScreen } from "./design-system";

export default function VeloraHistory() {
  return <VeloraScreen initialPage="history" />;
}
