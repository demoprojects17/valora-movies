import { VeloraScreen } from "./design-system";

export default function VeloraSeries() {
  return <VeloraScreen initialPage="series" />;
}
