import { VeloraScreen } from "./design-system";

export default function VeloraProfile() {
  return <VeloraScreen initialPage="profile" />;
}
