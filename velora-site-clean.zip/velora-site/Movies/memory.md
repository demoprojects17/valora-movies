# Decisions

## User-authorized scope
- Create updated page designs based on the existing codebase, with attractive visual assets.
- Work only in Movies; the parent Velora codebase is read-only context.
- Communicate in Georgian.

## Findings and proposed direction
- Source: parent README.md, app/globals.css and index.html. The Next.js entry references components/VeloraApp, which was absent during inspection.
- Existing views: home, movies, anime, series, watchlist, viewing history. Keep tracking, rating, import and synchronization flows.
- Proposed visual direction is cinematic forest/emerald, derived from existing production colors; it has not yet been reviewed by the user.
- brief.md and art-direction.md are populated from source evidence. Theme colors match the existing app.

## Authorized alternative workflow
- User explicitly authorized proceeding without design-knowledge/design-studio after their unavailability was explained.
- Seven artboards: home, movies, series, anime, watchlist, history and add-title.
- Shared implementation is design-system.tsx; artboards/design-system.tsx is a symlink so artboards use the required ./design-system import.
- Built-in image generation created assets/cinema-atlas.png, a single four-scene artwork atlas. Prompt stored in assets/prompts.json. All artwork and demo titles are original, not actual film posters.
- Demo data are labeled. Search, navigation, sorting, rating, episode steps and adding demo titles work locally in preview; no production API integration or persistent cloud state.
- No animation was introduced.
- Validation complete: all seven artboards compile and render through SWC and React. Local Chrome screenshots saved under .shots at 1200, 768 and 390; no horizontal overflow on any screen. Desktop and mobile home screenshots visually reviewed. Browser checks passed for search, adding a title, episode increment and status filtering, with no browser errors. Studio-specific lint is unavailable.

## Personal cabinet
- User requested their personal cabinet design. Added profile artboard, keeping the forest/emerald direction and existing artwork. No additional image generation.
- Source: components/VeloraApp.jsx profile dialog: email, saved title count, cloud status, resync, other-device guidance and logout. Extended into a full profile page with statistics, settings and demo recent activity.
- Name editing and demo backup download work; cloud/account operations are explicitly demo states. Added cabinet navigation and clickable header avatar.
- Profile verification: SWC/React compilation passed; Chrome checked 1200, 768 and 390 without horizontal overflow. Desktop and mobile screenshots reviewed; mobile identity alignment corrected. Name editing, demo resync state and JSON download passed, with no browser errors.

## Homepage release-led redesign
- User requested the slogan box replaced by current movies/series, followed by new movies, new anime, then series.
- Homepage discovery has a manual three-feature selector, real release cards, detail dialog and working watchlist controls; statistics remain on profile.
- Metadata checked against Netflix Tudum, Sony Pictures, KADOKAWA and Disney+/Hulu on 2026-10-12. Featured titles have already released as of that date; no invented ratings. Platform season dates are labeled; Georgia availability is not asserted.
- Official promotional artwork downloaded into assets/releases; preview uses local paths. Existing generated atlas remains for demo-library and profile art.
- Validation: all eight artboards compile/render. Updated home checked at 1200, 768 and 390 in Chrome; all 12 local promo artworks loaded, no horizontal overflow and correct movie/anime/series order. Desktop/mobile screenshots visually reviewed. Feature selector, details modal, save to watchlist, retained saved state and removal passed without browser errors.

## Phone layout refinement
- User requested the same visual style with an organized phone layout. Added home-mobile artboard and refined all screens at widths <=600.
- Five-item fixed bottom navigation; watchlist/history remain accessible through header shortcuts. Search has its own field and add action.
- Homepage categories use compact chips and horizontal two-visible-card rails, in movies/anime/series order. Existing local images and release snapshot retained.
- Comfortable touch targets, bottom safe-area padding, bottom-sheet details and toast spacing. No new assets or animation.
- Phone validation passed at 360, 390, 768 and 1200 for home-mobile, movies, anime, series, watchlist, history and profile, with no horizontal page overflow. Visually reviewed 390 homepage. Bottom navigation, watchlist shortcut, saving and detail sheet passed without browser errors. All nine artboards compile/render.

## Night / bright mode
- User requested two styled modes toggled with a moon icon. Added moon/sun header control on all screens and mobile.
- Choice persists in localStorage under velora.design.theme; explicit home-night and home-bright artboards provide deterministic comparisons.
- Bright palette defined in theme.json: warm sage/ivory, white surfaces, dark forest text, deep green accents. Hero remains cinematic with white copy. All cards, profile, dialogs, bottom navigation and fields are restyled.
- Theme validation: all eleven artboards compile/render. Night and bright home reviewed at 1200 and 390 with no overflow. Browser checks passed for toggling both ways, preference after reload, navigation to profile and bright edit dialog; no browser errors.

## Black night mode
- User explicitly replaced green night mode with a refined black design. Implemented black/graphite backgrounds, silver-white actions, neutral navigation and grayscale form/profile surfaces, including hero overlays and mobile navigation.
- Bright design and moon/sun preference behavior retained. Artwork remains naturally colored. Night tokens updated in theme.json.
- Verified all eleven artboards compile/render; black night layouts visually reviewed at 390 and 1200. Mode switching, persisted preference, bright profile and dialog checks passed without browser errors or overflow.

## Cinematic journal homepage
- User approved the proposed black cinema-journal direction: refined feature, three preview thumbnails below it, mood choices, ordered movie/anime/series shelves and compact continue-watching.
- Amber is a restrained homepage accent, with black/graphite surfaces retained. Bright remains supported. Existing local imagery and dated release snapshot retained.
- Mood controls filter the curated release catalog with a clear All reset. Continue-watching is conditional on active series/anime and supports marking episode progress within the preview.
- Journal validation: all eleven artboards compile/render. Both modes checked at 1200, 768, 390 and 360, with all images loaded and no overflow. Desktop/mobile screenshots visually reviewed. Mood filtering/reset, episode progress, feature selection and details passed without browser errors.

## Mood panel refinement
- User requested further refinement of the What to watch today box. Replaced flat pills with a framed graphite panel, four illustrated-by-code icon tiles, short mood captions, clear selected state, All reset and live result count.
- Desktop four-column / mobile two-column tiles; night and bright supported. No generated assets or animation. Existing filtering behavior retained; tapping an active mood clears it.
- Refined mood panel visually reviewed at 1200 and 390. Both modes passed filter/active-toggle-reset checks; all eleven artboards compile/render.

## Light palette refinement
- User requested a more refined light mode, especially colors. Replaced the green tint with warm porcelain/stone, charcoal typography, restrained bronze accents and consistent white surfaces.
- Light hero now uses an ivory gradient and dark text; controls, feature tabs, mood panel, poster badges, navigation, profile and dialogs use the same palette. Night unchanged.
- Light refinement checked in both themes at 360, 390, 768 and 1200; all artwork loaded and no overflow. Desktop/mobile light screenshots and profile reviewed. Mood filters, feature selection, progress, theme persistence and edit dialog passed without browser errors.
