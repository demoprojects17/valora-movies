# Art direction

## Mood
An intimate, cinematic personal film journal. Calm, atmospheric and refined, with clear library controls.

## Style & medium
Current night direction: black and graphite surfaces, generous spacing, bold Georgian headings and silver-white actions. Bright mode uses porcelain/stone, charcoal actions and bronze details. Photographic cinematic landscapes for artwork; restrained UI with crisp inline SVG icons. Preserve movie, anime and series distinctions through labels and progress controls.

## Palette (see theme.json)
Night: background #09090b; sidebar #0e0e11; panel #151518; borders #2a2a30; primary text #f4f4f5; secondary text #a1a1aa; silver accent #f0f0f3. Bright values are recorded in theme.json.

## Composition
Landscape hero artwork with dark, quiet negative space on the left for Georgian copy, atmospheric scenery on the right. Portrait artwork must remain legible at small card sizes. Desktop sidebar and spacious content; mobile compact navigation and a two-column library. Initial artboards use this direction; user visual review is pending.

## Avoid
Text baked into generated images, real people's faces, brand logos, copyrighted characters, excessive neon, cluttered controls, streaming-service promises and network-dependent preview assets. No animation is planned for the initial pass.

## Release-led homepage update
User requested a new-release feature panel instead of the slogan, then sections in this exact order: movies, anime, series. Use official local promotional artwork for actual titles, generous cinematic hero, manual feature selector and refined four-column desktop/two-column mobile cards. Avoid fabricated ratings and streaming buttons; expose details and watchlist controls. No animation or additional AI imagery.

## Phone composition
At 390px use a clean logo header with watchlist/history shortcuts, dedicated search row, cinematic feature panel, three category chips and compact horizontal poster rails. Persistent five-item bottom navigation with safe-area spacing. Use the selected night or bright palette with readable type and comfortable touch controls.

## Night and bright modes
Night uses neutral black, graphite panels and silver-white accents. Bright uses warm porcelain and stone backgrounds, white panels, charcoal text and restrained bronze details. Cinematic artwork remains rich and dark enough for readable white hero copy in both modes. Moon/sun switch is in the header on desktop and the logo row on mobile.

## Current night palette
User replaced green night mode with neutral black (#09090b), graphite surfaces (#151518), soft charcoal borders (#2a2a30), off-white type and silver primary controls. All UI surfaces, overlays, navigation and profile controls are neutral. Artwork keeps its natural colors. Bright mode retains its existing palette.

## Cinema-journal refinement
Homepage uses a large uncluttered feature, three standalone thumbnail selectors, restrained amber details (#d6ad6a), mood pills and generous poster shelves. Film/anime/series order stays fixed. Conditional continue-watching is placed below the discovery shelves to keep new releases primary. No animation or additional generated assets.

## Refined mood panel
Mood selector is a distinct graphite panel with subtle warm illumination, spacious heading, four tactile icon tiles with muted terracotta/gold/lilac/rose icon backgrounds, amber selected outlines and a quiet live-result footer. White/cream equivalent in bright mode.

## Current light direction
Warm porcelain #f6f5f3, white cards, stone sidebar #efeeeb, charcoal text #262429, neutral secondary text #716d75 and restrained bronze #96652d. Primary actions charcoal/white. Ivory hero gradient with dark copy, white poster badges and subtle shadows. This supersedes the earlier sage/green light palette.
