import "./globals.css";
import "./profile.css";
import "./releases.css";
import "./mobile.css";
import "./themes.css";

export const metadata = {
  title: "Velora — Movies & Series Tracker",
  description:
    "Movies, anime and series in one library, saved and synced across all your devices.",
  manifest: "/manifest.json",
  icons: { icon: "/favicon.svg", apple: "/apple-touch-icon.png" },
  appleWebApp: {
    capable: true,
    title: "Velora",
    statusBarStyle: "black-translucent",
  },
  robots: { index: false, follow: false },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#06100c",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ka" data-theme="night" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('velora.theme');document.documentElement.dataset.theme=t==='bright'?'bright':'night'}catch{}})()`,
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
